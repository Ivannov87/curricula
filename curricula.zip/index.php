<?php

require_once "controller/rootsC.php";
require_once "controller/adminC.php";
require_once "model/rootsM.php";
require_once "model/adminM.php";
$roots = new Roots();
$roots -> LoginTemplate();



