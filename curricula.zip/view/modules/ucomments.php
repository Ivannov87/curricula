<?php
 $update = new CommentC();
 $update-> UpdateCR();
