
<?php
     $recibidos = new CommentC();
     $recibidos->Enviados(); 
?>
