<?php
 $update = new CommentC();
 $update-> UpdateC();
