
<?php
     $recibidos = new CommentC();
     $recibidos->Recibidos(); 
?>
